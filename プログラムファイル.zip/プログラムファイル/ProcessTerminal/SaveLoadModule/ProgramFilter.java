package ProcessTerminal.SaveLoadModule;

import DataIO.DataFilter;
import KUU.BaseComponent.BaseFrame;

public class ProgramFilter extends DataFilter{
    @Override
    public String getDescription() {
        return "Circuitor 命令データ";
    }
}
