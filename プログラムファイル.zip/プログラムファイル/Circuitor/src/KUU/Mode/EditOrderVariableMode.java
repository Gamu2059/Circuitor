package KUU.Mode;

/**
 * 命令入力パネルの変数の列挙型
 */
public enum EditOrderVariableMode {
    CONSTANT,
    PIN,
    VARIABLE,
    ARRAY,
    SQUARE,
}
