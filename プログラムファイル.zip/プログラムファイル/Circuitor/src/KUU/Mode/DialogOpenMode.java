package KUU.Mode;

/**
 * ダイアログを開くモードの列挙型
 */
public enum DialogOpenMode {
    ADD,
    EDIT,
}
