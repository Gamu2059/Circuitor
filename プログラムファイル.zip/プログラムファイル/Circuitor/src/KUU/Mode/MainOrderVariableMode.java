package KUU.Mode;

/**
 * メイン操作パネルの変数の列挙型
 */
public enum MainOrderVariableMode {
    FUNCTION,
    VARIABLE,
    ARRAY,
    SQUARE,
}
