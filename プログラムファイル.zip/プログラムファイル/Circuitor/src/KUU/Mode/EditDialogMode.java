package KUU.Mode;

/**
 * エディタパネルの命令ダイアログの列挙型
 */
public enum EditDialogMode {
    SUBSTITUTION,
    CALC,
    IF,
    FOR,
    WHILE,
    LOADFUNCTION,
}
