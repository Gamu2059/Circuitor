package KUU.FrameWorkComponent.CircuitComponent;

import KUU.BaseComponent.BaseFrame;
import KUU.NewComponent.NewJPanel;
import Sho.CircuitObject.UnitPanel.CircuitUnitPanel;

/**
 * 回路モードでのエディタ領域の画面。
 */
public class EditCircuitPanel extends CircuitUnitPanel {
    public EditCircuitPanel(BaseFrame frame) {
        super(frame);
    }

}

