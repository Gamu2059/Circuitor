package KUU.FrameWorkComponent.ExecuteComponent;

import KUU.BaseComponent.BaseFrame;
import KUU.NewComponent.NewJPanel;
import Sho.CircuitObject.UnitPanel.ExecuteUnitPanel;

/**
 * 実行モードでのエディタ領域の画面。
 */
public class EditExecutePanel extends ExecuteUnitPanel {
    public EditExecutePanel(BaseFrame frame) {
        super(frame);
    }

}
