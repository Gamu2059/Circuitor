package KUU.GeneralComponent;

import javax.swing.*;

/**
 * 中央に文字が入力されるJTextField
 */
public class GeneralTextField extends JTextField{
    public GeneralTextField() {
        this.setHorizontalAlignment(CENTER);
    }

}
